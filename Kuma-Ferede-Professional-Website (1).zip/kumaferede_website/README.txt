KUMA FEREDE GOBOSH — PROFESSIONAL PROFILE WEBSITE

Files:
- index.html: complete responsive personal profile website
- assets/profile-photo.png: profile photograph
- assets/Kuma-Ferede-CV.pdf: CV download file

Preview:
Open index.html in a web browser.

Free publishing:
Option A — GitHub Pages (free):
1. Create/sign in to a GitHub account at https://github.com
2. Create a public repository named kumaferede.github.io
3. Upload index.html and the assets folder (keep the folder structure).
4. In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
5. After publishing, the site address will be https://kumaferede.github.io

Important:
- This package is ready to publish, but it has not been published online.
- The custom domain kumaferede.com is not connected or registered.
- Google indexing is not guaranteed and may take time.
- The MBA institution was updated to Addis Ababa University as requested. The 2023–2025 dates and CGPA 3.75 were carried over from the supplied CV's education entry; please verify those details before publishing.
